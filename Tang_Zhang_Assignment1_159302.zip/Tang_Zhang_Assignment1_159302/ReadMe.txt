This assignment was written by Francis Tang 15053399 and Ran Zhang 15004584.

C++ programming language is used for this assignment.

gcc and ScITE are the compiler and IDE we used for this assignment.

Please note that the two batch files provided cannot work very well by clicking it directly, but typing command to the cmd window separately will often work smoothly instead.

P.S. The first experiment (initial state: 042158367) and the last experiment (initial state: 471506238) are extremely hard to find a solution for the puzzle problem. The computer will keep searching all the time which may takes ages for a result (longer than 1000 seconds)